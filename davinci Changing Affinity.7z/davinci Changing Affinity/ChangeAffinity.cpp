//include base Windows libraries
#include <windows.h>
#include <winbase.h>
//include Windows libraries for getting process affinity and process IDs
#include <process.h>
#include <tlhelp32.h>

//include C++ libraries for string manipulation
#include <iostream>
#include <string>
#include <vector>

int main( int argc, char* argv[] )
{
	//check if the user has entered the correct number of arguments
	if( argc != 2 )
	{
		std::cout << "Usage: ChangeAffinity.exe <process name>" << std::endl;
		return 1;
	}


	//get the process name from the user
	std::string processName = argv[1];

	//get the process id of the process name
	DWORD processID = GetProcessID( processName );

	//check if the process id is valid
	if( processID == 0 )
	{
		std::cout << "Process not found" << std::endl;
		return 1;
	}


	//get the process affinity
	DWORD processAffinity = GetProcessAffinity( processID );

	//check if the process affinity is valid
	if( processAffinity == 0 )
	{
		std::cout << "Process affinity not found" << std::endl;
		return 1;
	}


	//get the system affinity
	DWORD systemAffinity = GetSystemAffinity();

	//check if the system affinity is valid
	if( systemAffinity == 0 )
	{
		std::cout << "System affinity not found" << std::endl;
		return 1;
	}


	//get the process affinity mask
	DWORD processAffinityMask = GetProcessAffinityMask( processAffinity );

	//check if the process affinity mask is valid
	if( processAffinityMask == 0 )
	{
		std::cout << "Process affinity mask not found" << std::endl;
		return 1;
	}


	//get the system affinity mask
	DWORD systemAffinityMask = GetSystemAffinityMask( systemAffinity );

	//check if the system affinity mask is valid
	if( systemAffinityMask == 0 )
	{
		std::cout << "System affinity mask not found" << std::endl;
		return 1;
	}

	//get the process affinity mask
	DWORD processAffinityMask2 =